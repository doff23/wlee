<?php
$conn = mysqli_connect("localhost", "root", "", "doffrent");
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>